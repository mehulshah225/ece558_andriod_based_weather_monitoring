package com.example.mqtt

import android.annotation.SuppressLint
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mqtt.databinding.ActivityMainBinding
import com.google.android.material.slider.Slider
import org.eclipse.paho.client.mqttv3.*

@Suppress("PrivatePropertyName")
class MainActivity : AppCompatActivity() {
    private val TAG = MainActivity::class.java.simpleName

    private lateinit var binding: ActivityMainBinding
    private lateinit var mqttClient: MQTTClient
    private lateinit var mqttClientID: String
    private  var LEDState: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if Internet connection is available
        // exit if it is not
        if (!isConnected()) {
            Log.d(TAG, "Internet connection NOT available")
            Toast.makeText(this, "Internet connection NOT available", Toast.LENGTH_LONG).show()
            finish()
        } else {
            Log.d(TAG, "Connected to the Internet")
            Toast.makeText(this, "Connected to the Internet", Toast.LENGTH_LONG).show()
        }

        // open mQTT Broker communication
        mqttClientID = MqttClient.generateClientId()
        mqttClient = MQTTClient(this, MQTT_SERVER_URI, mqttClientID)


        // Connect to MQTT Broker and subscribe to the status topic
        mqttClient.connect(
            MQTT_USERNAME,
            MQTT_PWD,
            object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(TAG, "Connection success")

                    val successMsg = "MQTT Connection to $MQTT_SERVER_URI Established"
                    Toast.makeText(this@MainActivity, successMsg, Toast.LENGTH_LONG).show()

                    // subscribe to the status topics
                    subscribetoMQTT()
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.d(TAG, "Connection failure: ${exception.toString()}")
                    val failureMsg =
                        "MQTT Connection to $MQTT_SERVER_URI failed: ${exception?.toString()}"
                    Toast.makeText(this@MainActivity, failureMsg, Toast.LENGTH_LONG).show()
                    exception?.printStackTrace()
                }
            },

            object : MqttCallback {
                override fun messageArrived(topic: String?, message: MqttMessage?) {
                    val msg = "Received message: ${message.toString()} from topic: $topic"
                    Log.d(TAG, msg)

                    // update the status textview
                    // since a message arrived I'm assuming that the topic string is not null
                    when (topic) {
                        Temperature -> {
                            val mes = "%.2f".format(message.toString().toFloat())
                            binding.temperature.text = mes //message.toString()
                        }
                        Humidity -> {
                            val humi = "%.2f".format(message.toString().toFloat())
                            binding.humidity.text = humi
                        }
                        Button_status -> {
                            binding.buttonstatus.text = message.toString()
                        }
                    }
                }

                override fun connectionLost(cause: Throwable?) {
                    Log.d(TAG, "Connection lost ${cause.toString()}")
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) {
                    Log.d(TAG, "Delivery complete")
                }
            })


        // Disconnect from MQTT Broker if connected
        if (mqttClient.isConnected()) {
            mqttClient.disconnect(object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(TAG, "Disconnected from $$MQTT_SERVER_URI")
                    Toast.makeText(
                        this@MainActivity,
                        "MQTT Disconnection success",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.d(TAG, "Failed to disconnect exception: ${exception.toString()}")
                }
            })
        } else {
            Log.d(TAG, "Impossible to disconnect, no server connected")
        }

        // LED change listeners
        binding.Btnstatus.setOnClickListener {
            // Publish the LiteOn message
            LEDState = LEDState != true
            changeLEDState(LEDState.toString())
        }
        binding.intervalSlider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener{
            @SuppressLint("RestrictedApi")
            override fun onStartTrackingTouch(slider: Slider) {
                // Responds to when slider's touch event is being started
            }
            @SuppressLint("RestrictedApi")
            override fun onStopTrackingTouch(slider: Slider) {
                // Responds to when slider's touch event is being stopped
                publishInterval(slider.value.toInt())
            }
        })
        /*binding.intervalSlider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {

*/
    }
    // helper functions
    private fun isConnected(): Boolean {
        var result = false
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = cm.getNetworkCapabilities(cm.activeNetwork)
        if (capabilities != null) {
            result = when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> true
                else -> false
            }
        }
        return result
    }


    private fun subscribetoMQTT() {
        Log.d("MQTT", "Subscribing to topics")

        if (mqttClient.isConnected()) {
            mqttClient.subscribe(
                topic = Temperature,
                qos = 1,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        Log.d("MQTT", "Subscribed to temperature")
                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        Log.d("MQTT", "Could not subscribe to temperature")
                    }
                }
            )

            mqttClient.subscribe(
                topic = Humidity,
                qos = 1,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        Log.d("MQTT", "Subscribed to humidity")
                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        Log.d("MQTT", "Could not subscribe to humidity")
                    }
                }
            )

            mqttClient.subscribe(
                topic = Button_status,
                qos = 1,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        Log.d("MQTT", "Subscribed to button")
                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        Log.d("MQTT", "Could not subscribe to button")
                    }
                }
            )

            mqttClient.subscribe(
                topic = LED,
                qos = 1,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        Log.d("MQTT", "Subscribed to device status")
                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        Log.d("MQTT", "Could not subscribe to device status")
                    }
                }
            )
        }
    }
    private fun changeLEDState(message: String) {
        if (mqttClient.isConnected()) {
            val topic = LED
            mqttClient.publish(
                topic,
                message,
                1,
                false,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        val msg = "Successfully published message: $message to topic: $topic"
                        Log.d(TAG, msg)


                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        val msg =
                            "Failed to publish: $message to topic: $topic exception: ${exception.toString()}"
                        Log.d(TAG, msg)
                    }
                })
        } else {
            Log.d(TAG, "Impossible to publish, no server connected")
        }
    }

    private fun publishInterval(interval:Int){
        val message = interval.toString()
        if (mqttClient.isConnected()) {
            val topic = Interval
            mqttClient.publish(
                topic,
                message,
                1,
                false,
                object : IMqttActionListener {
                    override fun onSuccess(asyncActionToken: IMqttToken?) {
                        val msg = "Successfully published message: $message to topic: $topic"
                        Log.d(TAG, msg)


                    }

                    override fun onFailure(
                        asyncActionToken: IMqttToken?,
                        exception: Throwable?
                    ) {
                        val msg =
                            "Failed to publish: $message to topic: $topic exception: ${exception.toString()}"
                        Log.d(TAG, msg)
                    }
                })
        } else {
            Log.d(TAG, "Impossible to publish, no server connected")
        }
    }
}
